#--kind python:default
#-a mcp:type tool
#-a mcp:desc "A message as a tool."
#-a input:str "the input to echo"
import tool
def main(args):
  return tool.tool(args)
