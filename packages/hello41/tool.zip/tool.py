def tool(args):
  input = args.get("input", "")
  output = input
  return { "output": f"Tool: {output}" }
