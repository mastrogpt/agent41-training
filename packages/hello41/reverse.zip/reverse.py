def reverse(args):
  input = args.get("input", "")
  output = input[::-1]
  return { "output": output }