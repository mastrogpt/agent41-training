def prompt(args):
  input = args.get("input", "")
  output = input
  return { "output": f"prompt: {output}" }
