#--kind python:default
#-a mcp:type prompt
#-a mcp:desc "Create an echo prompt"
#-a input:str "the input to echo"

import prompt
def main(args):
  return prompt.prompt(args)
