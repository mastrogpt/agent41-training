def resource(args):
  input = args.get("input", "")
  output = input
  return { "output": f"resource: {output}" }
