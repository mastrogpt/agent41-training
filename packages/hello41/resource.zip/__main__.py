#--kind python:default
#-a mcp:type resource
#-a mcp:desc "Echoes a resource."
#-a mcp:resource "echo://{input}"
#-a input:str "the input to echo"
import resource
def main(args):
  return resource.resource(args) 
